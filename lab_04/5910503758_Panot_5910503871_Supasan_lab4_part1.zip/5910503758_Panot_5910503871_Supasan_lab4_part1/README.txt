We finally finish part1_1(expreval.c) at 12.11pm
We studied entire code that spent our time a lot.
And make test case is a bit hard. :(
 